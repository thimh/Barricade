﻿public class StartField : Field
{
    public Color Color { get; set; }
}

