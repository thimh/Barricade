﻿public class Barricade
{
    public string Icon { get { return "O "; } }
}

