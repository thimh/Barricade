﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarricaeModelLib.GeneratedCode.Model
{
    public class PathField:Field
    {
        public override string Icon => "| ";
    }
}
