﻿namespace BarricadeConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            new Controller.Controller();
            System.Console.ReadLine();
        }
    }
}
